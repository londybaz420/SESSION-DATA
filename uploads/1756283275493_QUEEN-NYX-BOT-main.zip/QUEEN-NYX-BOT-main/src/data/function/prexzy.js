{
	"name": "QUEEN NYX Bot Multi Device "
}