//========RAZKI========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283171588369"] 
global.namabot = 'Takeshi Crasher'
//======================
global.mess = { 
owner: '*waduhh!, lu bukan owner gw bg*',
premium: '*anda bukan user premium*',
succes: '*done bang*'
}
//======================